// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    const std::string account_number = "CharlieBrown42";
    std::string user_input; // Use std::string to handle user input dynamically.

    std::cout << "Enter a value (up to 19 characters): ";
    getline(std::cin, user_input); // Safely read the line into a std::string.

    // Enforce a maximum length of 19 characters.
    if (user_input.length() > 19) {
        std::cout << "Input truncated to 19 characters for security." << std::endl;
        user_input = user_input.substr(0, 19); // Truncate to the first 19 characters.
    }

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;

    return 0;
}

